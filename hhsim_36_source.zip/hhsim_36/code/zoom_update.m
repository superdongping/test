function test_name

vc_vertslider_val;
vc_slider_val;
slider_val;
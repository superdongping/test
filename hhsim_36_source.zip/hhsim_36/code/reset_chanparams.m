function reset_chanparams

  global handles

  reset_valbox(handles.g_passNa)
  reset_valbox(handles.g_passK)
  reset_valbox(handles.g_passCl)

  % should add code here to turn default channels back on
  % also add code to reset all channel details
  